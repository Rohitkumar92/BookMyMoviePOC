import { Component, OnInit, Output, EventEmitter, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-add-theater',
  templateUrl: './add-theater.component.html',
  styleUrls: ['./add-theater.component.scss']
})
export class AddTheaterComponent implements OnInit {

  newTheater = this.fb.group({
    tid: ['', this.tidValidator],
    name: ['', Validators.pattern(/^[A-Za-z ]+$/)],
    city: ['', Validators.compose([Validators.pattern(/^[A-Za-z ]+$/)])],
    gLocation: ['', Validators.compose([Validators.pattern(/^[A-Za-z ]+$/)])],
    capacity: ['',this.capacityValidator]
  });

  @Output() addTheater = new EventEmitter();
  @ViewChild('successDialog') successDialog: TemplateRef<any>;

  constructor(private fb: FormBuilder, private matDialog: MatDialog) {
  }

  ngOnInit() {
  }
  onSubmit() {
    if (this.newTheater.valid) {
      this.matDialog.open(this.successDialog);
      this.addTheater.emit(this.newTheater.value);
    }
  }
  dialogOk() {
    this.newTheater.reset();
    this.matDialog.closeAll();
  }

   capacityValidator (control: AbstractControl):{[key: string]: boolean} | null {

    if( control.value !==null && (isNaN(control.value) || control.value <200  || control.value> 500)){
      return {'capacityValidator': true}
    }
    return null;
  };

  tidValidator (control: AbstractControl):{[key: string]: boolean} | null {

    if( control.value !==null && (isNaN(control.value) || control.value <10000  || control.value> 99999)){
      return {'tidValidator': true}
    }
    return null;
  };
 
}
