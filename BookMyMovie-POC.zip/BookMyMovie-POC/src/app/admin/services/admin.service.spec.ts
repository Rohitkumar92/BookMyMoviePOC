import { TestBed } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Store, StoreModule } from '@ngrx/store';
import { AdminService } from './admin.service';
import { of, Observable } from 'rxjs';

class StoreMock {
    select = jasmine.createSpy().and.returnValue(of(true));
}

describe('AdminService', () => {
    let service: AdminService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [AdminService, StoreModule,
                { provide: Store, useClass: StoreMock }],
            schemas: [NO_ERRORS_SCHEMA]
        });
        service = TestBed.get(AdminService);
        httpMock = TestBed.get(HttpTestingController);
    });


    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should search searchMovie function', () => {
        let spy = spyOn(service, 'searchMovie');
        expect(spy).toHaveBeenCalled;
    });

    it('should call newTheater function', () => {
        let spy = spyOn(service, 'newTheater');
        expect(spy).toHaveBeenCalled;
    });
    
})