import {
  Component,
  OnInit,
  Input,
  ChangeDetectionStrategy,
  ViewChild,
  EventEmitter,
  Output
} from '@angular/core';

import { HomeService } from '../../services/home.service';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import * as MovieState from '../../../reducers/index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HomePageComponent implements OnInit {
  @ViewChild(CdkVirtualScrollViewport) virtualScroll: CdkVirtualScrollViewport;

  @Input()
  moviesList;

  @Input()
  upcomingList;

  @Input()
  theaterList;

  @Input()
  userPreference;

  @Output()
  getNewNowPlayingMovies: EventEmitter<number> = new EventEmitter<number>();

  @Output()
  getNewUpcomingMovies: EventEmitter<number> = new EventEmitter<number>();
  sortMovie = '';
  sortClick = false;
  page = 10;
  click = false;
  activeTabIndex = 0;
  nowPlayingMovieFetchedPageNum = 1;
  upcomingMoviesFetchedPageNum = 0;
  selectedLanguage = '';
  selectedGenre = '';
  languageList = [{ id: 'en', name: 'English' }, { id: 'ja', name: 'Japanese' }, { id: 'zh', name: 'Chinese' }];
  constructor(private homeService: HomeService,
    private store: Store<MovieState.State>) {}

  ngOnInit() {
    this.getNewNowPlayingMovies.emit(1);
    this.getNewUpcomingMovies.emit(1);
  }

  trackMovie(index, movie) {
    if (movie) {
      return movie.id;
    } else {
      return -1;
    }
  }

  getMovies(): void {
    if (this.virtualScroll.getDataLength() === this.virtualScroll.getRenderedRange().end) {
      console.log("page number", this.page);
      if (this.activeTabIndex === 0) {
        this.getNewNowPlayingMovies.emit(++this.page);
      }
      else if (this.activeTabIndex === 1) {
        this.getNewUpcomingMovies.emit(++this.page);
      }
    }
  }

  tabChanged(event) {
    this.activeTabIndex = event;
  }

  getLanguage(lang) {
    this.selectedLanguage = lang;
  }

  getGenre(g) {
    this.selectedGenre = g;
  }

  sort() {
    this.sortClick = !this.sortClick;
    this.sortClick?this.sortMovie ='desc': this.sortMovie ='asc';
  }

  ngAfterViewInit(): void {
    this.store.select(MovieState.nowPlayingMoviesSelector).subscribe(result => this.moviesList = result);
    this.store.select(MovieState.upcomingMovieSelector).subscribe(result => this.upcomingList = result);
  }
}
