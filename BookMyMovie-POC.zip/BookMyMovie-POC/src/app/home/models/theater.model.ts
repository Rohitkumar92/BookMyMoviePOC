export interface Theater {
    id: string;
    name: string;
    location: string;
    address: string;
    city: string;
    shows: [];
}
