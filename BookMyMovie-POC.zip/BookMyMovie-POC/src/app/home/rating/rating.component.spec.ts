import {ComponentFixture, TestBed} from '@angular/core/testing';
import {RatingComponent} from './rating.component';
 
describe('RatingComponent', () => {
  let component: RatingComponent;
  let fixture: ComponentFixture<RatingComponent>;
let vote_average;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RatingComponent]
    });
  });
 
  beforeEach(() => {
    fixture = TestBed.createComponent(RatingComponent);
    component = fixture.componentInstance;
  });
 
  function getEmptyStars(): HTMLSpanElement[] {
    return fixture.nativeElement.querySelectorAll('[data-jest="empty star"]');
  }
 
  function getFullStars(): HTMLSpanElement[] {
    return fixture.nativeElement.querySelectorAll('[data-jest="full star"]');
  }
 
  function getHalfStar(): HTMLSpanElement {
    return fixture.nativeElement.querySelector('[data-jest="half star"]');
  }
});