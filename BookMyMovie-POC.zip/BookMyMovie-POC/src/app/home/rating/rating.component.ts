import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss']
})
export class RatingComponent implements OnInit {
  private readonly MAX_NUMBER_OF_STARS = 5;
  rating = 0;
  @Input() movie;
  constructor() { }

  ngOnInit() {
  }

private get numberOfFullStars(): number {
this.rating = this.movie.vote_average/2;
return Math.floor(this.rating);
  }
 
private get numberOfEmptyStars(): number {
return this.MAX_NUMBER_OF_STARS - Math.ceil(this.rating);
  }
 
get fullStars(): any[] {
return Array(this.numberOfFullStars);
  }
 
get emptyStars(): any[] {
return Array(this.numberOfEmptyStars);
  }
 
get hasAnHalfStar(): boolean {
return this.rating % 1 !== 0;
  }
}


