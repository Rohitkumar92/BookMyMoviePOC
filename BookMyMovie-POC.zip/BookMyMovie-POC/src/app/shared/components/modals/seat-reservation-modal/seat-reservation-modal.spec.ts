import { async, ComponentFixture, TestBed } from'@angular/core/testing';
 
import { SeatReservationModalComponent } from'./seat-reservation-modal.component';
import { MaterialModule } from'src/app/material.module';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from'@angular/material';
import { CUSTOM_ELEMENTS_SCHEMA } from'@angular/core';
import { RouterTestingModule } from'@angular/router/testing';
 
describe('SeatReservationModalComponent', () => {
let component: SeatReservationModalComponent;
let fixture: ComponentFixture<SeatReservationModalComponent>;
const dialogMock = {
close: () => { }
    };
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [SeatReservationModalComponent],
imports: [MaterialModule, MatDialogModule, RouterTestingModule],
providers: [{ provide:MatDialogRef, useValue:dialogMock }, { provide:MAT_DIALOG_DATA, useValue: [] }],
schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));
 
beforeEach(() => {
fixture = TestBed.createComponent(SeatReservationModalComponent);
component = fixture.componentInstance;
 
fixture.detectChanges();
  });
 
it('should create', () => {
expect(component).toBeTruthy();
  });
 
it('should create', () => {
spyOn(sessionStorage, 'getItem').and.callFake((key) => {
return"Rohit";
    });
component.ngOnInit()
  });
 
it('should create', () => {
component.reserved = ["A2", "A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
component.getStatus("A2");
expect(component.getStatus("A2")).toEqual("reserved")
  });
 
it('should create', () => {
component.selected = ["A2", "A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
component.getStatus("A1")
  });
 
it('should create', () => {
component.reserved = ["A1", "A3", "B5", "C1", "C2", "D4"];
component.selected = ["A2", "A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
component.getStatus("A2");
expect(component.getStatus("A2")).toEqual("selected")
  });
 
it('should create', () => {
component.reserved = ["A1", "A3", "B5", "C1", "C2", "D4"];
component.selected = ["A2", "A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
component.seatClicked("A2");
 
  });
 
it('should create', () => {
component.reserved = ["A1", "A3", "B5", "C1", "C2", "D4"];
component.selected = ["A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
component.seatClicked("A2");
 
  });
it('should create', () => {
component.reserved = ["A2", "A3", "B5", "C1", "C2", "D4"];
component.selected = ["A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
component.seatClicked("A2");
 
  });
 
it('should create', () => {
let spy = spyOn(component.dialogRef, 'close').and.callThrough();
component.onNoClick()
expect(spy).toHaveBeenCalled();   
 
  });
it('should create', () => {
let spy = spyOn(component.dialogRef, 'close').and.callThrough();
component.onCloseCancel()
expect(spy).toHaveBeenCalled();   
 
  });
it('should create', () => {

component.movieTitle="",
component.time="",
component.selected = ["A3", "B5", "C1", "C2", "D4"];
fixture.detectChanges();
 
let spy = spyOn(component.dialogRef, 'close').and.callThrough();
component.onCloseConfirm()
expect(spy).toHaveBeenCalled();   
 
  });
 
});

